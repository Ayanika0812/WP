# webapp/urls.py
from django.urls import path  # Import path from django.urls

from . import views  # Assuming you have views to handle the URLs

urlpatterns = [
    path('', views.index, name='index'),  # Replace `url()` with `path()`
    # Add other URL patterns here
]
