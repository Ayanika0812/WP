from django.apps import AppConfig

class MagazineCoverConfig(AppConfig):
    name = 'magazine_cover'
