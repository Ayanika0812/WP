"""from django import forms

class MagazineCoverForm(forms.Form):
    title = forms.CharField(label='Magazine Title', max_length=100, required=True)
    subtitle = forms.CharField(label='Subtitle', max_length=200, required=True)
    image = forms.ImageField(label='Upload Image', required=True)
    background_color = forms.CharField(label='Background Color (Hex Code)', max_length=7, required=True)
    font_color = forms.CharField(label='Font Color (Hex Code)', max_length=7, required=True)
    font_size = forms.IntegerField(label='Font Size', min_value=10, max_value=100, required=True)
"""

# magazine_cover/forms.py
from django import forms

class MagazineCoverForm(forms.Form):
    title = forms.CharField(max_length=100)
    image = forms.ImageField()  # Image field
    bg_color = forms.CharField(max_length=7)  # For hex color code, like #ffffff
    font_color = forms.CharField(max_length=7)  # For hex color code
