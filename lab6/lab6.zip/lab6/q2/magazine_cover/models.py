from django.db import models

class MagazineCover(models.Model):
    image = models.ImageField(upload_to='covers/', null=True, blank=True)
    title = models.CharField(max_length=100)
    subtitle = models.CharField(max_length=100)
    text_color = models.CharField(max_length=7, default="#000000")  # Hex color for text
    font_size = models.IntegerField(default=50)  # Font size in px
    background_color = models.CharField(max_length=7, default="#ffffff")  # Hex color for background
