# magazine_cover/urls.py
from django.urls import path
from . import views  # Import views from the current app (magazine_cover)

urlpatterns = [
    path('', views.generate_cover, name='form'),  # Map the root URL to the form page
]
