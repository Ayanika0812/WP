# magazine_cover/views.py
from django.shortcuts import render
from .forms import MagazineCoverForm  # Assuming you already have a form

def generate_cover(request):
    if request.method == 'POST':
        # Handle the form submission
        form = MagazineCoverForm(request.POST, request.FILES)
        if form.is_valid():
            # Get the data from the form
            title = form.cleaned_data['title']
            image = form.cleaned_data['image']
            bg_color = form.cleaned_data['bg_color']
            font_color = form.cleaned_data['font_color']
            # Pass this data to the result template
            return render(request, 'magazine_cover/result.html', {
                'title': title,
                'image': image,
                'bg_color': bg_color,
                'font_color': font_color,
            })


    else:
        # If the request method is GET, just show the form
        form = MagazineCoverForm()

    # Return the form in case of GET request
    return render(request, 'magazine_cover/form.html', {'form': form})
