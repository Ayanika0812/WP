# carapp/forms.py

from django import forms

class CarForm(forms.Form):
    MANUFACTURERS = [
        ('toyota', 'Toyota'),
        ('ford', 'Ford'),
        ('honda', 'Honda'),
    ]

    manufacturer = forms.ChoiceField(choices=MANUFACTURERS, label='Car Manufacturer')
    model = forms.CharField(max_length=100, label='Car Model')
