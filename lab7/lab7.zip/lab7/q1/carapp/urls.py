# carapp/urls.py

from django.urls import path
from . import views

urlpatterns = [
    path('', views.index_view, name='index'),  # URL for the form
    path('result/', views.result_view, name='result'),  # URL to show results after form submission
]

