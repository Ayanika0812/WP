# carapp/views.py

from django.shortcuts import render, redirect
from .forms import CarForm

def index_view(request):
    if request.method == 'POST':
        form = CarForm(request.POST)
        if form.is_valid():
            # Get the cleaned data from the form
            manufacturer = form.cleaned_data['manufacturer']
            model = form.cleaned_data['model']

            # Redirect to result page with the manufacturer and model as query parameters
            return redirect(f'/result/?manufacturer={manufacturer}&model={model}')
    else:
        form = CarForm()

    return render(request, 'carapp/index.html', {'form': form})

# carapp/views.py

def result_view(request):
    manufacturer = request.GET.get('manufacturer', 'No manufacturer selected')
    model = request.GET.get('model', 'No model provided')

    return render(request, 'carapp/result.html', {
        'manufacturer': manufacturer,
        'model': model
    })
