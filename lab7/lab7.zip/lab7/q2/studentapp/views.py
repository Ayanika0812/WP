# studentapp/views.py
from django.shortcuts import render, redirect
from django.http import HttpResponse

def first_page(request):
    if request.method == 'POST':
        # Get data from the form
        name = request.POST.get('name')
        roll = request.POST.get('roll')
        subject = request.POST.get('subject')

        # Store the data in the session
        request.session['name'] = name
        request.session['roll'] = roll
        request.session['subject'] = subject

        # Redirect to the second page
        return redirect('second_page')
    
    return render(request, 'firstPage.html')  # Make sure this path is correct

def second_page(request):
    # Retrieve the data from the session
    name = request.session.get('name', '')
    roll = request.session.get('roll', '')
    subject = request.session.get('subject', '')

    if not name or not roll or not subject:
        return HttpResponse("Session data is missing. Please submit the form first.")

    context = {
        'name': name,
        'roll': roll,
        'subject': subject
    }
    
    return render(request, 'secondPage.html', context)  # Again, ensure this path is correct
