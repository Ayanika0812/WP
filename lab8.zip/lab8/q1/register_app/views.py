# register_app/views.py

from django.shortcuts import render, redirect
from django.contrib import messages
from django.middleware.csrf import get_token
# register_app/views.py

from django.shortcuts import render, redirect

def home(request):
    # Redirect to the register page
    return redirect('register')

def register(request):
    if request.method == "POST":
        # Get data from form
        username = request.POST.get('username')
        password = request.POST.get('password')
        email = request.POST.get('email')
        contact_number = request.POST.get('contact_number')

        # Check if the username is empty
        if not username:
            messages.error(request, "Username is required")
            return render(request, 'register_app/register.html')

        # Save user data in session
        request.session['username'] = username
        request.session['email'] = email
        request.session['contact_number'] = contact_number

        # Redirect to the success page
        return redirect('success')

    return render(request, 'register_app/register.html', {'csrf_token': get_token(request)})

def success(request):
    username = request.session.get('username')
    email = request.session.get('email')
    contact_number = request.session.get('contact_number')

    if username:
        return render(request, 'register_app/success.html', {
            'username': username,
            'email': email,
            'contact_number': contact_number
        })
    else:
        return redirect('register')
