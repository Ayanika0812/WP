from django.db import models

class Choice(models.Model):
    text = models.CharField(max_length=100)
    votes = models.IntegerField(default=0)

    def __str__(self):
        return self.text

# After making this change, don't forget to make and apply migrations:
# python manage.py makemigrations
# python manage.py migrate
