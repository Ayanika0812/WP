from django.urls import path
from . import views

urlpatterns = [
    path('', views.vote_view, name='vote'),  # Voting form
    path('results/', views.results_view, name='results'),  # Results page
]
