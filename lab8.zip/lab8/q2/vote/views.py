from django.shortcuts import render
from .models import Choice

def vote_view(request):
    choices = Choice.objects.all()
    total_votes = sum(choice.votes for choice in choices)

    if request.method == 'POST':
        choice_id = request.POST.get('choice')
        if choice_id:
            choice = Choice.objects.get(id=choice_id)
            choice.votes += 1
            choice.save()

    return render(request, 'vote/vote.html', {'choices': choices, 'total_votes': total_votes})

def results_view(request):
    choices = Choice.objects.all()
    total_votes = sum(choice.votes for choice in choices)

    # Calculate the percentage of votes for each choice
    for choice in choices:
        if total_votes > 0:
            choice.vote_percentage = (choice.votes / total_votes) * 100
        else:
            choice.vote_percentage = 0

    return render(request, 'vote/results.html', {'choices': choices, 'total_votes': total_votes})
