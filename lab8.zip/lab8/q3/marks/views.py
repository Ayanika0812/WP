from django.shortcuts import render, redirect
from .forms import CGPAForm  # Import the form class

def home(request):
    if request.method == 'POST':
        form = CGPAForm(request.POST)
        if form.is_valid():
            name = form.cleaned_data['name']
            total_marks = form.cleaned_data['total_marks']
            
            # Store in session
            request.session['name'] = name
            request.session['total_marks'] = total_marks
            
            return redirect('result')  # Redirect to result page
    else:
        form = CGPAForm()  # Initialize an empty form

    return render(request, 'marks/home.html', {'form': form})


def result(request):
    name = request.session.get('name', 'Guest')
    total_marks = request.session.get('total_marks', 0)
    
    # Calculate CGPA
    if total_marks:
        cgpa = total_marks / 50
    else:
        cgpa = 0
        
    return render(request, 'marks/result.html', {'name': name, 'cgpa': cgpa})
