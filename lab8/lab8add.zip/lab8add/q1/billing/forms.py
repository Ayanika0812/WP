from django import forms

class BillForm(forms.Form):
    # Radio buttons for selecting the brand
    brand = forms.ChoiceField(
        choices=[('HP', 'HP'), ('Nokia', 'Nokia'), ('Samsung', 'Samsung'), 
                 ('Motorola', 'Motorola'), ('Apple', 'Apple')],
        widget=forms.RadioSelect,
        label="Select Brand"
    )
    
    # Checkbox for selecting product types
    product_type = forms.MultipleChoiceField(
        choices=[('Mobile', 'Mobile'), ('Laptop', 'Laptop')],
        widget=forms.CheckboxSelectMultiple,
        label="Select Product Type"
    )
    
    # Quantity input
    quantity = forms.IntegerField(min_value=1, label="Enter Quantity")
