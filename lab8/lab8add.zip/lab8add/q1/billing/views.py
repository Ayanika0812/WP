from django.shortcuts import render
from .forms import BillForm

# Create view for displaying the form and the bill
def index(request):
    if request.method == 'POST':
        form = BillForm(request.POST)
        if form.is_valid():
            # Process the form data
            brand = form.cleaned_data['brand']
            product_type = form.cleaned_data['product_type']
            quantity = form.cleaned_data['quantity']
            
            # Calculate the total price based on brand and product type
            price = 0
            if brand == 'HP':
                price = 1000
            elif brand == 'Nokia':
                price = 500
            elif brand == 'Samsung':
                price = 800
            elif brand == 'Motorola':
                price = 600
            elif brand == 'Apple':
                price = 1200

            total_amount = price * quantity
            
            return render(request, 'billing/bill.html', {
                'brand': brand,
                'product_type': product_type,
                'quantity': quantity,
                'total_amount': total_amount,
            })
    else:
        form = BillForm()

    return render(request, 'billing/index.html', {'form': form})
