# feedback/forms.py
from django import forms

class FeedbackForm(forms.Form):
    name = forms.CharField(label='Name', max_length=100)
    email = forms.EmailField(label='Email')
    feedback_type = forms.ChoiceField(
        label='Feedback Type',
        choices=[('ASP-XML', 'ASP-XML'), 
                 ('DotNET', 'DotNET'), 
                 ('JavaPro', 'JavaPro'), 
                 ('Unix,C,C++', 'Unix,C,C++')],
        widget=forms.Select
    )
    comments = forms.CharField(widget=forms.Textarea, label='Comments')
