# q2/urls.py
from django.contrib import admin
from django.urls import path
from feedback import views

urlpatterns = [
    path('admin/', admin.site.urls),
    path('feedback/', views.feedback_view, name='feedback'),  # Feedback form URL
    path('', views.feedback_view, name='root_feedback'),  # Root URL mapped to feedback form
]
